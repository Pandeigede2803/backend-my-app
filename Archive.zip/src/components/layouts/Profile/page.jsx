import Image from "next/image";

const Profil = () => {
  return (
    <div className="flex flex-col justify-center items-center">
      <h1>DEDE SUDIAHNA</h1>
    </div>
  );
};

export default Profil;
