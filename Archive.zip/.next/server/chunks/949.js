"use strict";
exports.id = 949;
exports.ids = [949];
exports.modules = {

/***/ 6378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);




function PortoCards({ Image, ProjectTitle, Description, Categories, id, URL }) {
    const cardSize = "400px"; // Set the desired width and height here
    const cardStyle = {
        width: cardSize,
        height: cardSize
    };
    // Check if URL is defined and not empty
    const isUrlValid = URL && URL.trim() !== "";
    const openUrlInNewTab = ()=>{
        // Use window.open to open the URL in a new tab
        if (isUrlValid) {
            window.open(URL, "_blank");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative mx-10 my-10 bg-white rounded-lg overflow-hidden shadow-lg transition-transform transform hover:scale-105 duration-300 ease-in-out",
        style: cardStyle,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: `/images/${Image}`,
                alt: ProjectTitle,
                className: "w-full h-full object-cover object-center"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "absolute top-0 left-0 right-0 bottom-0 bg-black opacity-0 hover:opacity-80 transition-opacity duration-300 ease-in-out flex flex-col justify-center p-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-xl text-center  text-white font-semibold",
                        children: ProjectTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-white mt-2 text-center",
                        children: Description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-4 items-center flex justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "bg-white text-gray-600 text-xs px-2 py-1 rounded-full text-center",
                            children: Categories
                        })
                    }),
                    isUrlValid && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: " items-center mx-auto flex flex-col justify-center mt-2 w-fit bg-blue-500 hover:bg-blue-600 text-white py-2 px-2 rounded rounded-2xl",
                        onClick: openUrlInNewTab,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaSearch, {}),
                            " "
                        ]
                    })
                ]
            })
        ]
    }, id);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PortoCards);


/***/ }),

/***/ 7949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Portofolio)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _porto_cards_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6378);




function Portofolio() {
    const [projects, setProjects] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedCategory, setSelectedCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("ALL"); // Initialize with 'ALL'
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Fetch data from the API endpoint
        fetch("http://localhost:5000/api/projects").then((response)=>response.json()).then((data)=>setProjects(data)).catch((error)=>console.error("Error fetching data:", error));
    }, [
        selectedCategory
    ]);
    // Function to filter projects based on the selected category
    const filteredProjects = selectedCategory === "ALL" ? projects : projects.filter((project)=>project.Categories.includes(selectedCategory));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col justify-center mx-auto my-20 mt-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-center font-plus-jakarta-sans text-4xl",
                        children: "PORTFOLIO"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col lg:flex-row justify-center items-center lg:space-x-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `border border-2 hover:bg-[#A28BFF] w-44 rounded-md h-10 mt-6 px-2 font-plus-jakarta-sans ${selectedCategory === "ALL" ? "bg-[#A28BFF]" : ""}`,
                                onClick: ()=>setSelectedCategory("ALL"),
                                children: "ALL"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: `border border-2 hover:bg-[#A28BFF] w-auto rounded-md h-10 mt-6 px-2 font-plus-jakarta-sans ${selectedCategory === "DIGITAL MARKETING" ? "bg-[#A28BFF]" : ""}`,
                                onClick: ()=>setSelectedCategory("Digital Marketing"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaLaptop, {
                                        className: "inline-block mb-1"
                                    }),
                                    " DIGITAL MARKETING"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: `text-center border border-2 hover:bg-[#A28BFF] w-44 rounded-md h-10 mt-6 px-2 font-plus-jakarta-sans ${selectedCategory === "WEBSITE" ? "bg-[#A28BFF]" : ""}`,
                                onClick: ()=>setSelectedCategory("Website"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaCamera, {
                                        className: "inline-block mr-2 mb-1 my-auto"
                                    }),
                                    " WEBSITE"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: `border border-2 hover:bg-[#A28BFF] w-44 rounded-md h-10 mt-6 px-2 font-plus-jakarta-sans ${selectedCategory === "VIDEO/PHOTO" ? "bg-[#A28BFF]" : ""}`,
                                onClick: ()=>setSelectedCategory("Video/Photo"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaFilm, {
                                        className: "inline-block mr-2 mb-1"
                                    }),
                                    " VIDEO/PHOTO"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: `border border-2 hover:bg-[#A28BFF] w-44 rounded-md h-10 mt-6 px-2 font-plus-jakarta-sans ${selectedCategory === "DESIGN" ? "bg-[#A28BFF]" : ""}`,
                                onClick: ()=>setSelectedCategory("Design"),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaFilm, {
                                        className: "inline-block mr-2 mb-1"
                                    }),
                                    " DESIGN"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-wrap justify-center mt-4",
                children: filteredProjects.map((project)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_porto_cards_page__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        Image: project.Image,
                        ProjectTitle: project.ProjectTitle,
                        Description: project.Description,
                        Categories: project.Categories,
                        URL: project.URL
                    }, project.id))
            })
        ]
    });
}


/***/ })

};
;